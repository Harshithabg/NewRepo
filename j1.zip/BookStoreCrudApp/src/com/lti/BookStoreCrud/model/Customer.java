package com.lti.BookStoreCrud.model;

public class Customer {
	protected int CUSTOMER_ID;
	protected String FIRST_NAME;
	protected String LAST_NAME;
	protected String ADDRESS;
	protected String CITY;
	protected String STATE;
	protected String ZIPCODE;
	public Customer() {
	}
	public Customer(int cUSTOMER_ID, String fIRST_NAME, String lAST_NAME, String aDDRESS, String cITY, String sTATE,
			String zIPCODE) {
		super();
		CUSTOMER_ID = cUSTOMER_ID;
		FIRST_NAME = fIRST_NAME;
		LAST_NAME = lAST_NAME;
		ADDRESS = aDDRESS;
		CITY = cITY;
		STATE = sTATE;
		ZIPCODE = zIPCODE;
	}
	public Customer( String fIRST_NAME, String lAST_NAME, String aDDRESS, String cITY, String sTATE,
			String zIPCODE) {
		super();
		
		FIRST_NAME = fIRST_NAME;
		LAST_NAME = lAST_NAME;
		ADDRESS = aDDRESS;
		CITY = cITY;
		STATE = sTATE;
		ZIPCODE = zIPCODE;
	}
	public int getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public void setCUSTOMER_ID(int cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public String getCITY() {
		return CITY;
	}
	public void setCITY(String cITY) {
		CITY = cITY;
	}
	public String getSTATE() {
		return STATE;
	}
	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}
	public String getZIPCODE() {
		return ZIPCODE;
	}
	public void setZIPCODE(String zIPCODE) {
		ZIPCODE = zIPCODE;
	}
	@Override
	public String toString() {
		return "Customer [CUSTOMER_ID=" + CUSTOMER_ID + ", FIRST_NAME=" + FIRST_NAME + ", LAST_NAME=" + LAST_NAME
				+ ", ADDRESS=" + ADDRESS + ", CITY=" + CITY + ", STATE=" + STATE + ", ZIPCODE=" + ZIPCODE + "]";
	}
	
}

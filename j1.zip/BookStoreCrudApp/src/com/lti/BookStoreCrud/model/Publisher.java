package com.lti.BookStoreCrud.model;

public class Publisher {
	protected String PUBLISHER_CODE;
	protected int PUBLISHER_ID;
	protected String PUBLISHER_NAME;
	protected String EMAIL;
	protected String WEBSITE;
	
	public Publisher() {
	}
	public Publisher(String pUBLISHER_CODE, String pUBLISHER_NAME, String eMAIL, String wEBSITE) {
		super();
		PUBLISHER_CODE = pUBLISHER_CODE;
		
		PUBLISHER_NAME = pUBLISHER_NAME;
		EMAIL = eMAIL;
		WEBSITE = wEBSITE;
	}

	public Publisher(String pUBLISHER_CODE, int pUBLISHER_ID, String pUBLISHER_NAME, String eMAIL, String wEBSITE) {
		super();
		PUBLISHER_CODE = pUBLISHER_CODE;
		PUBLISHER_ID = pUBLISHER_ID;
		PUBLISHER_NAME = pUBLISHER_NAME;
		EMAIL = eMAIL;
		WEBSITE = wEBSITE;
	}
	public String getPUBLISHER_CODE() {
		return PUBLISHER_CODE;
	}
	public void setPUBLISHER_CODE(String pUBLISHER_CODE) {
		PUBLISHER_CODE = pUBLISHER_CODE;
	}
	public int getPUBLISHER_ID() {
		return PUBLISHER_ID;
	}
	public void setPUBLISHER_ID(int pUBLISHER_ID) {
		PUBLISHER_ID = pUBLISHER_ID;
	}
	public String getPUBLISHER_NAME() {
		return PUBLISHER_NAME;
	}
	public void setPUBLISHER_NAME(String pUBLISHER_NAME) {
		PUBLISHER_NAME = pUBLISHER_NAME;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getWEBSITE() {
		return WEBSITE;
	}
	public void setWEBSITE(String wEBSITE) {
		WEBSITE = wEBSITE;
	}
	@Override
	public String toString() {
		return "Publisher [PUBLISHER_CODE=" + PUBLISHER_CODE + ", PUBLISHER_ID=" + PUBLISHER_ID + ", PUBLISHER_NAME="
				+ PUBLISHER_NAME + ", EMAIL=" + EMAIL + ", WEBSITE=" + WEBSITE + "]";
	}
	
	
}

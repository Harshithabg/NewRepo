package com.lti.CollegeCrudAppDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.CollegeCrudAppBean.Student;

public class StudentDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "ilovejava";

	private static final String INSERT_USERS_SQL = "INSERT INTO STUDENT2 VALUES "
			+ " (student_seq.NEXTVAL,?, ?, ?, ?)";

	private static final String SELECT_USER_BY_ID = "select  STUDENT_ID,STUDENT_NAME,DOB,"
			+ "COURSE_ID,INST_ID from STUDENT2 where STUDENT_ID =?";
	private static final String SELECT_ALL_USERS = "select * from STUDENT2";
	private static final String DELETE_USERS_SQL = "delete from STUDENT2 where STUDENT_ID = ?";
	private static final String UPDATE_USERS_SQL = "update STUDENT2 set STUDENT_NAME = ?,"
			+ "DOB= ?, COURSE_ID =?, INST_ID =? where STUDENT_ID = ?";

	public StudentDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(Student user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setString(1, user.getSTUDENT_NAME());
			preparedStatement.setString(2, user.getDOB());
			preparedStatement.setInt(3, user.getCOURSE_ID());
			preparedStatement.setInt(4, user.getINST_ID());

			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Student selectUser(int STUDENT_ID) {
		Student user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, STUDENT_ID);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String STUDENT_NAME = rs.getString("STUDENT_NAME");
				String DOB = rs.getString("DOB");
				int COURSE_ID = rs.getInt("COURSE_ID");
				int INST_ID = rs.getInt("INST_ID");
				user = new Student(STUDENT_ID,STUDENT_NAME,DOB,COURSE_ID,INST_ID);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Student> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Student> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int STUDENT_ID = rs.getInt("STUDENT_ID");
				String STUDENT_NAME = rs.getString("STUDENT_NAME");
				String DOB = rs.getString("DOB");
				int COURSE_ID = rs.getInt("COURSE_ID");
				int INST_ID = rs.getInt("INST_ID");
				
				users.add(new Student(STUDENT_ID,STUDENT_NAME,DOB,COURSE_ID,INST_ID));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int STUDENT_ID) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, STUDENT_ID);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Student user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setString(1, user.getSTUDENT_NAME());
			statement.setString(2, user.getDOB());
			statement.setInt(3, user.getCOURSE_ID());
			statement.setInt(4, user.getINST_ID());
			statement.setInt(5, user.getSTUDENT_ID());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}

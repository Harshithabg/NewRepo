package com.lti.CollegeCrudAppDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.CollegeCrudAppBean.Department;



public class DepartmentDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "ilovejava";

	private static final String INSERT_USERS_SQL = "INSERT INTO DEPART VALUES "
			+ " (depart_seq.NEXTVAL,?,?)";

	private static final String SELECT_USER_BY_ID = "select  DEPT_ID,DEPT_NAME,LOCATION"
			+ " from DEPART  where DEPT_ID =?";
	private static final String SELECT_ALL_USERS = "select * from DEPART";
	private static final String DELETE_USERS_SQL = "delete from DEPART where DEPT_ID = ?";
	private static final String UPDATE_USERS_SQL = "update DEPART  set DEPT_NAME = ?,"
			+ "LOCATION= ? where DEPT_ID = ?";

	public DepartmentDAO () {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(Department user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setString(1, user.getDEPT_NAME());
			preparedStatement.setString(2, user.getLOCATION());
			
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Department selectUser(int DEPT_ID) {
		Department user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, DEPT_ID);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String DEPT_NAME = rs.getString("DEPT_NAME");
				String LOCATION = rs.getString("LOCATION");
				user = new Department(DEPT_ID,DEPT_NAME,LOCATION);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Department> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Department> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int DEPT_ID = rs.getInt("DEPT_ID");
				String DEPT_NAME = rs.getString("DEPT_NAME");
				String LOCATION = rs.getString("LOCATION");
			
				users.add(new Department(DEPT_ID,DEPT_NAME,LOCATION));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int DEPT_ID) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, DEPT_ID);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Department user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setString(1, user.getDEPT_NAME());
			statement.setString(2, user.getLOCATION());
			statement.setInt(3, user.getDEPT_ID());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}


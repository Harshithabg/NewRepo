package com.lti.CollegeCrudAppDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.CollegeCrudAppBean.Instructor;



public class InstructorDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "ilovejava";

	private static final String INSERT_USERS_SQL = "INSERT INTO INST VALUES "
			+ " (inst_seq.NEXTVAL,?, ?, ?, ?)";

	private static final String SELECT_USER_BY_ID = "select  INST_ID,INST_NAME,TELE_NO,"
			+ "ROOM_NO,DEPT_ID from INST where INST_ID =?";
	private static final String SELECT_ALL_USERS = "select * from INST";
	private static final String DELETE_USERS_SQL = "delete from INST where INST_ID = ?";
	private static final String UPDATE_USERS_SQL = "update INST set INST_NAME = ?,"
			+ "TELE_NO= ?, ROOM_NO =?, DEPT_ID =? where INST_ID = ?";

	public InstructorDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(Instructor user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setString(1, user.getINST_NAME());
			preparedStatement.setInt(2, user.getTELE_NO());
			preparedStatement.setInt(3, user.getROOM_NO());
			preparedStatement.setInt(4, user.getDEPT_ID());

			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Instructor selectUser(int INST_ID) {
		Instructor user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, INST_ID);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String INST_NAME = rs.getString("INST_NAME");
				int TELE_NO = rs.getInt("TELE_NO");
				int ROOM_NO = rs.getInt("ROOM_NO");
				int DEPT_ID = rs.getInt("DEPT_ID");
				user = new Instructor(INST_ID,INST_NAME,TELE_NO,ROOM_NO,DEPT_ID);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Instructor> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Instructor> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int INST_ID = rs.getInt("INST_ID");
				String INST_NAME = rs.getString("INST_NAME");
				int TELE_NO = rs.getInt("TELE_NO");
				int ROOM_NO = rs.getInt("ROOM_NO");
				int DEPT_ID = rs.getInt("DEPT_ID");
				users.add(new Instructor(INST_ID,INST_NAME,TELE_NO,ROOM_NO,DEPT_ID));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int INST_ID) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, INST_ID);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Instructor user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setString(1, user.getINST_NAME());
			statement.setInt(2, user.getTELE_NO());
			statement.setInt(3, user.getROOM_NO());
			statement.setInt(4, user.getDEPT_ID());
			statement.setInt(5, user.getINST_ID());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}

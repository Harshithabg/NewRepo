package com.lti.CollegeCrudAppDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.CollegeCrudAppBean.Course;



public class CourseDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "ilovejava";

	private static final String INSERT_USERS_SQL = "INSERT INTO COURSE VALUES "
			+ " (co_seq.NEXTVAL,?, ?, ?)";

	private static final String SELECT_USER_BY_ID = "select  COURSE_ID,COURSE_NAME,DURATION,"
			+ "INST_ID from COURSE where COURSE_ID =?";
	private static final String SELECT_ALL_USERS = "select * from COURSE";
	private static final String DELETE_USERS_SQL = "delete from COURSE where COURSE_ID = ?";
	private static final String UPDATE_USERS_SQL = "update COURSE set COURSE_NAME = ?,"
			+ "DURATION= ?, INST_ID =? where COURSE_ID = ?";

	public CourseDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(Course user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setString(1, user.getCOURSE_NAME());
			preparedStatement.setString(2, user.getDURATION());
			preparedStatement.setInt(3, user.getINST_ID());
			

			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Course selectUser(int COURSE_ID) {
		Course user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, COURSE_ID);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String COURSE_NAME = rs.getString("COURSE_NAME");
				String DURATION = rs.getString("DURATION");
				int INST_ID = rs.getInt("INST_ID");
				
				user = new Course(COURSE_ID,COURSE_NAME,DURATION,INST_ID);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Course> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Course> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int COURSE_ID = rs.getInt("COURSE_ID");
				String COURSE_NAME = rs.getString("COURSE_NAME");
				String DURATION = rs.getString("DURATION");
				int INST_ID = rs.getInt("INST_ID");
				
				users.add(new Course(COURSE_ID,COURSE_NAME,DURATION,INST_ID));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int COURSE_ID) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, COURSE_ID);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Course user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setString(1, user.getCOURSE_NAME());
			statement.setString(2, user.getDURATION());
			statement.setInt(3, user.getINST_ID());
			statement.setInt(4, user.getCOURSE_ID());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
}

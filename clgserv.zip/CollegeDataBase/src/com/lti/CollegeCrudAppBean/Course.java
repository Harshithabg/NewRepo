package com.lti.CollegeCrudAppBean;

public class Course {
	protected int COURSE_ID;
	protected String COURSE_NAME;
	protected String DURATION;
	protected int INST_ID;
	public Course(){ }
	public Course(int COURSE_ID, String COURSE_NAME, String DURATION, int INST_ID) {
		super();
		this.COURSE_ID = COURSE_ID;
		this.COURSE_NAME = COURSE_NAME;
		this.DURATION = DURATION;
		this.INST_ID = INST_ID;
	}
	public Course( String COURSE_NAME, String DURATION, int INST_ID) {
		super();
		
		this.COURSE_NAME = COURSE_NAME;
		this.DURATION = DURATION;
		this.INST_ID = INST_ID;
	}
	public int getCOURSE_ID() {
		return COURSE_ID;
	}
	public void setCOURSE_ID(int COURSE_ID) {
		this.COURSE_ID = COURSE_ID;
	}
	public String getCOURSE_NAME() {
		return COURSE_NAME;
	}
	public void setCOURSE_NAME(String COURSE_NAME) {
		this.COURSE_NAME = COURSE_NAME;
	}
	public String getDURATION() {
		return DURATION;
	}
	public void setDURATION(String DURATION) {
		this.DURATION = DURATION;
	}
	public int getINST_ID() {
		return INST_ID;
	}
	public void setINST_ID(int INST_ID) {
		this.INST_ID = INST_ID;
	}
	@Override
	public String toString() {
		return "Course [COURSE_ID=" + COURSE_ID + ", COURSE_NAME=" + COURSE_NAME + ", DURATION=" + DURATION
				+ ", INST_ID=" + INST_ID + "]";
	}
	
}

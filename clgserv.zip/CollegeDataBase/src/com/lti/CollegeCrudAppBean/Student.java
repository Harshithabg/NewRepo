package com.lti.CollegeCrudAppBean;

public class Student {
	protected int STUDENT_ID;
	protected String STUDENT_NAME;
	protected String DOB;
	protected int COURSE_ID;
	protected int INST_ID;
	public Student(){ }
	public Student(int STUDENT_ID, String STUDENT_NAME, String DOB, int COURSE_ID, int INST_ID) {
		super();
		this.STUDENT_ID = STUDENT_ID;
		this.STUDENT_NAME = STUDENT_NAME;
		this.DOB = DOB;
		this.COURSE_ID = COURSE_ID;
		this.INST_ID = INST_ID;
	}
	public Student( String STUDENT_NAME, String DOB, int COURSE_ID, int INST_ID) {
		super();
		this.STUDENT_NAME = STUDENT_NAME;
		this.DOB = DOB;
		this.COURSE_ID = COURSE_ID;
		this.INST_ID = INST_ID;
	}
	public int getSTUDENT_ID() {
		return STUDENT_ID;
	}
	public void setSTUDENT_ID(int STUDENT_ID) {
		this.STUDENT_ID = STUDENT_ID;
	}
	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}
	public void setSTUDENT_NAME(String STUDENT_NAME) {
		this.STUDENT_NAME = STUDENT_NAME;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String DOB) {
		this.DOB = DOB;
	}
	public int getCOURSE_ID() {
		return COURSE_ID;
	}
	public void setCOURSE_ID(int COURSE_ID) {
		this.COURSE_ID = COURSE_ID;
	}
	public int getINST_ID() {
		return INST_ID;
	}
	public void setINST_ID(int INST_ID) {
		this.INST_ID = INST_ID;
	}
	@Override
	public String toString() {
		return "Student [STUDENT_ID=" + STUDENT_ID + ", STUDENT_NAME=" + STUDENT_NAME + ", DOB=" + DOB + ", COURSE_ID="
				+ COURSE_ID + ", INST_ID=" + INST_ID + "]";
	}
	
	
}

package com.lti.BookStoreCrud.model;

public class Order {

	protected int ORDER_ID;
	protected String ORDER_DATE;
	protected String ORDER_STATUS;
	protected int CUSTOMER_ID;
	
	public Order(){}
	public Order(int ORDER_ID, String ORDER_DATE, String ORDER_STATUS, int CUSTOMER_ID) {
		super();
		this.ORDER_ID = ORDER_ID;
		this.ORDER_DATE = ORDER_DATE;
		this.ORDER_STATUS = ORDER_STATUS;
		this.CUSTOMER_ID = CUSTOMER_ID;
	}
	public Order( String ORDER_DATE, String ORDER_STATUS, int CUSTOMER_ID) {
		super();
		
		this.ORDER_DATE = ORDER_DATE;
		this.ORDER_STATUS = ORDER_STATUS;
		this.CUSTOMER_ID = CUSTOMER_ID;
	}
	public int getORDER_ID() {
		return ORDER_ID;
	}
	public void setORDER_ID(int ORDER_ID) {
		this.ORDER_ID = ORDER_ID;
	}
	public String getORDER_DATE() {
		return ORDER_DATE;
	}
	public void setORDER_DATE(String ORDER_DATE) {
		this.ORDER_DATE = ORDER_DATE;
	}
	public String getORDER_STATUS() {
		return ORDER_STATUS;
	}
	public void setORDER_STATUS(String ORDER_STATUS) {
		this.ORDER_STATUS = ORDER_STATUS;
	}
	public int getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public void setCUSTOMER_ID(int CUSTOMER_ID) {
		this.CUSTOMER_ID = CUSTOMER_ID;
	}
	@Override
	public String toString() {
		return "Order [ORDER_ID=" + ORDER_ID + ", ORDER_DATE=" + ORDER_DATE + ", ORDER_STATUS=" + ORDER_STATUS
				+ ", CUSTOMER_ID=" + CUSTOMER_ID + "]";
	}
	
	
}

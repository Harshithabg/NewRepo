package com.lti.BookStoreCrud.model;

public class Book {
	protected int ISBN;
	protected String BOOK_TITLE;
	protected int AUTHOR_ID;
	protected int PUBLISHER_ID;
	public Book(){}
	public Book(int ISBN, String BOOK_TITLE, int AUTHOR_ID, int PUBLISHER_ID) {
		super();
		this.ISBN = ISBN;
		this.BOOK_TITLE = BOOK_TITLE;
		this.AUTHOR_ID = AUTHOR_ID;
		this.PUBLISHER_ID = PUBLISHER_ID;
	}
	public Book( String BOOK_TITLE, int AUTHOR_ID, int PUBLISHER_ID) {
		super();
		
		this.BOOK_TITLE = BOOK_TITLE;
		this.AUTHOR_ID = AUTHOR_ID;
		this.PUBLISHER_ID = PUBLISHER_ID;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int ISBN) {
		this.ISBN = ISBN;
	}
	public String getBOOK_TITLE() {
		return BOOK_TITLE;
	}
	public void setBOOK_TITLE(String BOOK_TITLE) {
		this.BOOK_TITLE = BOOK_TITLE;
	}
	public int getAUTHOR_ID() {
		return AUTHOR_ID;
	}
	public void setAUTHOR_ID(int AUTHOR_ID) {
		this.AUTHOR_ID = AUTHOR_ID;
	}
	public int getPUBLISHER_ID() {
		return PUBLISHER_ID;
	}
	public void setPUBLISHER_ID(int PUBLISHER_ID) {
		this.PUBLISHER_ID = PUBLISHER_ID;
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", BOOK_TITLE=" + BOOK_TITLE + ", AUTHOR_ID=" + AUTHOR_ID + ", PUBLISHER_ID="
				+ PUBLISHER_ID + "]";
	}
	
}

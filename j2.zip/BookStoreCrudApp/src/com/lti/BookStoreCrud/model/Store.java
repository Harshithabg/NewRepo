package com.lti.BookStoreCrud.model;

public class Store {
	protected int STORE_ID;
	protected String ADDRESS;
	protected String CITY;
	protected String STATE;
	protected String ZIPCODE;
	
	public Store() {
	}

	public Store(int STORE_ID, String ADDRESS, String CITY, String STATE, String ZIPCODE) {
		super();
		this.STORE_ID = STORE_ID;
		this.ADDRESS = ADDRESS;
		this.CITY = CITY;
		this.STATE = STATE;
		this.ZIPCODE = ZIPCODE;
	}
	public Store(String ADDRESS, String CITY, String STATE, String ZIPCODE) {
		super();
		
		this.ADDRESS = ADDRESS;
		this.CITY = CITY;
		this.STATE = STATE;
		this.ZIPCODE = ZIPCODE;
	}

	public int getSTORE_ID() {
		return STORE_ID;
	}

	public void setSTORE_ID(int STORE_ID) {
		this.STORE_ID = STORE_ID;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String ADDRESS) {
		this.ADDRESS = ADDRESS;
	}

	public String getCITY() {
		return CITY;
	}

	public void setCITY(String CITY) {
		this.CITY = CITY;
	}

	public String getSTATE() {
		return STATE;
	}

	public void setSTATE(String STATE) {
		this.STATE = STATE;
	}

	public String getZIPCODE() {
		return ZIPCODE;
	}

	public void setZIPCODE(String ZIPCODE) {
		this.ZIPCODE = ZIPCODE;
	}

	@Override
	public String toString() {
		return "Store [STORE_ID=" + STORE_ID + ", ADDRESS=" + ADDRESS + ", CITY=" + CITY + ", STATE=" + STATE
				+ ", ZIPCODE=" + ZIPCODE + "]";
	}
	
	
	
	
	
	
	
}

package ColllegeCrudAppServlet;

import CollegeCrudAppDAO.DepartmentDAO;

@WebServlet("/")
public class DepartmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DepartmentDAO userDAO;
	
	public void init() {
		userDAO = new DepartmentDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Department> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("depart-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("depart-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int DEPT_ID = Integer.parseInt(request.getParameter("DEPT_ID"));
		Department existingUser = userDAO.selectUser(DEPT_ID);
		RequestDispatcher dispatcher = request.getRequestDispatcher("depart-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String DEPT_NAME = request.getParameter("DEPT_NAME");
		String LOCATION= request.getParameter("LOCATION");
		Department newUser = new Department(DEPT_NAME, LOCATION);
		userDAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int DEPT_ID = Integer.parseInt(request.getParameter("DEPT_ID"));
		String FIRST_NAME = request.getParameter("DEPT_NAME");
		String LAST_NAME = request.getParameter("LOCATION");
		Department book = new Department(DEPT_ID,DEPT_NAME,LOCATION );
		userDAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int DEPT_ID = Integer.parseInt(request.getParameter("DEPT_ID"));
		userDAO.deleteUser(DEPT_ID);
		response.sendRedirect("list");

	}

}

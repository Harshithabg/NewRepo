package CollegeCrudAppBean;

public class Instructor {
	protected int  INST_ID;
	protected String INST_NAME;
	protected int TELE_NO;
	protected int  ROOM_NO;
	protected int DEPT_ID;
	public Instructor( ) { }
	public Instructor(int INST_ID, String INST_NAME, int TELE_NO, int ROOM_NO, int DEPT_ID) {
		super();
		this.INST_ID = INST_ID;
		this.INST_NAME = INST_NAME;
		this.TELE_NO = TELE_NO;
		this.ROOM_NO = ROOM_NO;
		this.DEPT_ID = DEPT_ID;
	}
	public Instructor( String INST_NAME, int TELE_NO, int ROOM_NO, int DEPT_ID) {
		super();
		this.INST_NAME = INST_NAME;
		this.TELE_NO = TELE_NO;
		this.ROOM_NO = ROOM_NO;
		this.DEPT_ID = DEPT_ID;
	}
	public int getINST_ID() {
		return INST_ID;
	}
	public void setINST_ID(int INST_ID) {
		this.INST_ID = INST_ID;
	}
	public String getINST_NAME() {
		return INST_NAME;
	}
	public void setINST_NAME(String INST_NAME) {
		this.INST_NAME = INST_NAME;
	}
	public int getTELE_NO() {
		return TELE_NO;
	}
	public void setTELE_NO(int TELE_NO) {
		this.TELE_NO = TELE_NO;
	}
	public int getROOM_NO() {
		return ROOM_NO;
	}
	public void setROOM_NO(int ROOM_NO) {
		this.ROOM_NO = ROOM_NO;
	}
	public int getDEPT_ID() {
		return DEPT_ID;
	}
	public void setDEPT_ID(int DEPT_ID) {
		this.DEPT_ID = DEPT_ID;
	}
	@Override
	public String toString() {
		return "Instructor [INST_ID=" + INST_ID + ", INST_NAME=" + INST_NAME + ", TELE_NO=" + TELE_NO + ", ROOM_NO="
				+ ROOM_NO + ", DEPT_ID=" + DEPT_ID + "]";
	}
	
	
}

package CollegeCrudAppBean;

public class Department {
	protected int  DEPT_ID;
	protected String DEPT_NAME;
	protected String LOCATION;
	public Department() {}
	public Department(int DEPT_ID, String DEPT_NAME, String LOCATION) {
		super();
		this.DEPT_ID = DEPT_ID;
		this.DEPT_NAME = DEPT_NAME;
		this.LOCATION = LOCATION;
	}
	public Department(String DEPT_NAME, String LOCATION) {
		super();
		
		this.DEPT_NAME = DEPT_NAME;
		this.LOCATION = LOCATION;
	}
	public int getDEPT_ID() {
		return DEPT_ID;
	}
	public void setDEPT_ID(int DEPT_ID) {
		this.DEPT_ID = DEPT_ID;
	}
	public String getDEPT_NAME() {
		return DEPT_NAME;
	}
	public void setDEPT_NAME(String DEPT_NAME) {
		this.DEPT_NAME = DEPT_NAME;
	}
	public String getLOCATION() {
		return LOCATION;
	}
	public void setLOCATION(String LOCATION) {
		this.LOCATION = LOCATION;
	}
	@Override
	public String toString() {
		return "Department [DEPT_ID=" + DEPT_ID + ", DEPT_NAME=" + DEPT_NAME + ", LOCATION=" + LOCATION + "]";
	}
	
	
}

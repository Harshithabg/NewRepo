package com.lti.AuthorCrud.model;

public class Author {
	private int AUTHOR_ID;
	private String FIRST_NAME;
	private String LAST_NAME;
	private String EMAIL;
	public Author(){
	}
	public Author( String fIRST_NAME, String lAST_NAME, String eMAIL) {
		super();
		
		FIRST_NAME = fIRST_NAME;
		LAST_NAME = lAST_NAME;
		EMAIL = eMAIL;
	}
	public Author(int aUTHOR_ID, String fIRST_NAME, String lAST_NAME, String eMAIL) {
		super();
		AUTHOR_ID = aUTHOR_ID;
		FIRST_NAME = fIRST_NAME;
		LAST_NAME = lAST_NAME;
		EMAIL = eMAIL;
	}
	public int getAUTHOR_ID() {
		return AUTHOR_ID;
	}
	public void setAUTHOR_ID(int aUTHOR_ID) {
		AUTHOR_ID = aUTHOR_ID;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	@Override
	public String toString() {
		return "AuthorBean [AUTHOR_ID=" + AUTHOR_ID + ", FIRST_NAME=" + FIRST_NAME + ", LAST_NAME=" + LAST_NAME
				+ ", EMAIL=" + EMAIL + "]";
	}

}

package com.lti.jpa.hibernate.model;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args){
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Scanner sc=new Scanner(System.in);
		entityManager.getTransaction().begin();
	/*	System.out.println("starting trancation");
		entityManager.getTransaction().begin();
		Orders order = new Orders();
		System.out.println("Enter Order Name :");
		String oname=sc.nextLine();
		order.setOrderName(oname);
		
//		System.out.println("Enter Order Date :");
//		String date_or=sc.nextLine();
	order.setCreateDate(new GregorianCalendar(2017,01,15));
		 System.out.println("saving employee to database");
		 entityManager.persist(order);
		 entityManager.getTransaction().commit();
		 System.out.println("successfully added to db");
		 
		 */
		/* 
		 
		 System.out.println("Enter Id for Updating");
		 int id_find=sc.nextInt();
		 Orders ord1 = (Orders)entityManager.find(Orders.class, id_find);
		 System.out.println("get object" + ord1.getOrderName() + " " + ord1.getOrderID()+ " " +ord1.getCreateDate());
		
		 System.out.println("Enter New Order Name for Updating");
		 String U_name=sc.nextLine();
		 ord1.setOrderName(U_name);
		 entityManager.merge(ord1);
		 entityManager.getTransaction().commit();
		 System.out.println("successfully updated to db");
*/
		//entityManager.persist(order);
		 
		 Orders or = entityManager.find(Orders.class, 48);
		 entityManager.remove(or);
		 entityManager.getTransaction().commit();
		 System.out.println("successfully removed to db");

		/* 
		 System.out.println("generated Order ID = " + order.getOrderID());
		 
		Orders ord = entityManager.find(Orders.class, order.getOrderID() );
		System.out.println("get object" + ord.getOrderName() + " " + ord.getOrderID()+ " " +ord.getCreateDate());
		
		 
		 @SuppressWarnings("unchecked")
		 
		 List<Orders> listOrders = entityManager.createQuery("SELECT e FROM Orders e").getResultList();
		  if(listOrders == null){
			   System.out.println("No orders found");
		  }else{
			  for(Orders ord12 : listOrders){
				  System.out.println("Order name =" + ord12.getOrderName() + ",Order id ="+ ord12.getOrderID() + ",Order Date ="+ ord12.getCreateDate() );
			  }
		  }*/
		  entityManager.close();
		  entityManagerFactory.close();
}
}

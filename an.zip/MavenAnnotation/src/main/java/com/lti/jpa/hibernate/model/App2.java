package com.lti.jpa.hibernate.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App2 {
public static void main(String[] args){
	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	System.out.println("starting trancation");
	entityManager.getTransaction().begin();
	Employee90 employee = new Employee90();
	employee.setName("harshitha");
	employee.setBranch("bangalore");
	 System.out.println("saving employee to database");
	 entityManager.persist(employee);
	 entityManager.getTransaction().commit();
	 System.out.println("generated employee ID = " + employee.getEmployeeId());
	 
	 Employee90 emp = entityManager.find(Employee90.class, employee.getEmployeeId() );
	 
	 System.out.println("get object" + emp.getName() + " " + emp.getEmployeeId());
	 
	 @SuppressWarnings("unchecked")
	 
	 List<Employee90> listEmployee = entityManager.createQuery("SELECT e FROM Employee90  e").getResultList();
	  if(listEmployee == null){
		   System.out.println("No employee found");
	  }else{
		  for(Employee90 emp1 : listEmployee){
			  System.out.println("Employee name =" + emp1.getName() + ",Employee id ="+ emp1.getEmployeeId() );
		  }
	  }
	  entityManager.close();
	  entityManagerFactory.close();
}
}

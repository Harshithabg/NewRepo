package com.lti.jpa.hibernate.model;

import java.time.LocalDate;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Orders45")
public class Orders {
	private int OrderID;
	private String OrderName;
	
	private Calendar createDate;
	@Id
	@Column(name = "orderid")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceName")
	@SequenceGenerator(name="somesequenceName",sequenceName="orde_seq",allocationSize =1)
	public int getOrderID() {
		return OrderID;
	}
	public void setOrderID(int orderID) {
		OrderID = orderID;
	}
	@Column(name = "ordname")
	public String getOrderName() {
		return OrderName;
	}
	public void setOrderName(String orderName) {
		OrderName = orderName;
	}
	@Temporal(TemporalType.DATE)	
	@Column(name = "orderdate")
	
	public Calendar getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Calendar createDate) {
		this.createDate = createDate;
	}

	
	
	
}
